using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Login.Models;

namespace Login.Controllers
{
    public class LoginController : Controller
    {

        public const string LOGIN = "_UserLogin";

        [HttpGet]
        public IActionResult AddUser()
        {
            return View();
        }

        [HttpPost]
        public IActionResult DoAddUser(LoginViewModel model)
        {

            try{
                //raises an error
                if(!LoginValidator.ValidateUsername(model.Username)){}
                if(!LoginValidator.ValidatePassword(model.Password)){}
            }
            catch(Exception exp)
            {
                ViewData["ErrorMessage"] = exp.Message;
                return View("ErrorAddUser");
            }

            Repository.AddLogin(model);
            return View(model);
        }

        [HttpGet]
        public IActionResult Login()
        {
            
            if(HttpContext.Session.GetString(LOGIN) == null){
                ViewData["IsLoggedIn"] = false;
                ViewData["LoginMessage"] = "Is Logged In";           
                return View();
                
            }else{

                string loginname = HttpContext.Session.GetString(LOGIN);
                LoginViewModel lvm = Repository.ValidateLogin(loginname);
                ViewData["IsLoggedIn"] = true;
                ViewData["LoginMessage"] = "Is Logged In";                     
                
                //chapter 5
                return View(lvm);
            }

        }

        [HttpPost]
        public IActionResult DoLogin(LoginViewModel model)
        {

            if(Repository.ValidatePassword(model)){

                //overwrite session
                HttpContext.Session.Clear();
                HttpContext.Session.SetString(LOGIN, model.Username);

                //set values for the view
                ViewData["IsLoggedIn"] = true;
                ViewData["LoginMessage"] = "Is Logged In";
            }
            else
            {
                //login was not correct
                ViewData["IsLoggedIn"] = false;
                ViewData["LoginMessage"] = "Username and/or Password is incorrect";
            }

            return View(model);
        }

        [HttpGet]
        public IActionResult Logout()
        {

            HttpContext.Session.Clear();
            ViewData["IsLoggedIn"] = false;
            ViewData["LoginMessage"] = "User is logged out";
            return Redirect("~/Home/Index");
} 

    }
}