using System.Collections.Generic;

namespace Login.Models {

    public static class Repository {
        
        private static List<LoginViewModel> logins = new List<LoginViewModel>()
        {
            new LoginViewModel(){Username = "test@test.com", Password = "xXyYzZaA"}
        };

        public static IEnumerable<LoginViewModel> Logins {
            get {
                return logins;
            }
        }

        public static LoginViewModel ValidateLogin(string username)
        {
            foreach(LoginViewModel lvm in Repository.Logins)
            {
                if(username == lvm.Username)
                {
                    return lvm;
                }
            }

            return null;
        }

        public static bool ValidatePassword(LoginViewModel login)
        {
            foreach(LoginViewModel lvm in Repository.Logins)
            {
                if(login.Username == lvm.Username && login.Password == lvm.Password)
                {
                    return true;
                }
            }

            return false;
        }

        public static void AddLogin(LoginViewModel login) {
            logins.Add(login);
        }
    }
}