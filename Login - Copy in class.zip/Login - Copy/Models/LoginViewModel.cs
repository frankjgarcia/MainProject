using System;

namespace Login.Models
{
    public class LoginViewModel
    {
        public string Email { get; set; }
        public string password {get; set;}

    }
}